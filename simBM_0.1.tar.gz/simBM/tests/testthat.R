library(testthat)
library(simBM)
test_check("simBM")
