context("simBM")

test_that("simBM works", {

    expect_equal(length(simBM(1000,2)), 2000)
    

				})
